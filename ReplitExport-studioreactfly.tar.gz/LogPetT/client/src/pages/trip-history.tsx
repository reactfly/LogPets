import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Search, Edit2, Trash2, Route } from "lucide-react";
import type { Trip } from "@shared/schema";

export default function TripHistory() {
  const [searchPlate, setSearchPlate] = useState("");
  const [plateFilter, setPlateFilter] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: trips, isLoading } = useQuery({
    queryKey: ["/api/trips", plateFilter],
    queryFn: async () => {
      const url = plateFilter ? `/api/trips?plate=${plateFilter}` : "/api/trips";
      const response = await apiRequest("GET", url);
      return response.json();
    },
  });

  const deleteTripMutation = useMutation({
    mutationFn: async (tripId: number) => {
      const response = await apiRequest("DELETE", `/api/trips/${tripId}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/trips"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({
        title: "Sucesso",
        description: "Viagem excluída com sucesso!",
      });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Erro ao excluir viagem",
        variant: "destructive",
      });
    },
  });

  const handleSearch = () => {
    setPlateFilter(searchPlate);
  };

  const handleDeleteTrip = (tripId: number) => {
    if (window.confirm("Tem certeza que deseja excluir esta viagem?")) {
      deleteTripMutation.mutate(tripId);
    }
  };

  const formatCurrency = (value: string | number) => {
    return `R$ ${parseFloat(value.toString()).toLocaleString('pt-BR', { 
      minimumFractionDigits: 2,
      maximumFractionDigits: 2 
    })}`;
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('pt-BR');
  };

  const calculateDistance = (trip: Trip) => {
    return trip.finalKm - trip.initialKm;
  };

  const calculateTotalCost = (trip: Trip) => {
    return parseFloat(trip.fuelCost || "0") + 
           parseFloat(trip.tollCost || "0") + 
           parseFloat(trip.parkingCost || "0") + 
           parseFloat(trip.otherCosts || "0");
  };

  const calculateEfficiency = (trip: Trip) => {
    const distance = calculateDistance(trip);
    const fuelCost = parseFloat(trip.fuelCost || "0");
    if (fuelCost > 0 && distance > 0) {
      const avgFuelPrice = 5.50; // Assuming average fuel price
      const liters = fuelCost / avgFuelPrice;
      return (distance / liters).toFixed(1);
    }
    return "N/A";
  };

  const getPurposeColor = (purpose: string) => {
    switch (purpose.toLowerCase()) {
      case 'trabalho': return 'bg-[#18A192]/10 text-[#18A192]';
      case 'pessoal': return 'bg-[#1976D2]/10 text-[#1976D2]';
      case 'reunião': return 'bg-[#FF6F00]/10 text-[#FF6F00]';
      default: return 'bg-gray-100 text-gray-600';
    }
  };

  // Get unique license plates for filter
  const uniquePlates = Array.from(new Set((trips as Trip[] || []).map((trip: Trip) => trip.licensePlate)));

  return (
    <div className="p-4 pb-20">
      {/* Search Bar */}
      <Card className="card-shadow mb-4">
        <CardContent className="p-4">
          <div className="flex space-x-3">
            <div className="flex-1">
              <Input
                placeholder="Buscar por placa..."
                value={searchPlate}
                onChange={(e) => setSearchPlate(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
              />
            </div>
            <Button 
              onClick={handleSearch} 
              className="px-4 bg-[#18A192] hover:bg-[#138A7E]"
            >
              <Search size={20} />
            </Button>
          </div>
          
          {/* Filter Options */}
          <div className="flex space-x-2 mt-3">
            <Select value={plateFilter} onValueChange={(value) => setPlateFilter(value === "all" ? "" : value)}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Todas as placas" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas as placas</SelectItem>
                {uniquePlates.map((plate) => (
                  <SelectItem key={plate} value={plate}>{plate}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            {plateFilter && (
              <Button 
                variant="outline" 
                onClick={() => {
                  setPlateFilter("");
                  setSearchPlate("");
                }}
              >
                Limpar
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Trip List */}
      <div className="space-y-3">
        {isLoading ? (
          // Loading skeletons
          [1, 2, 3].map((i) => (
            <Card key={i} className="card-shadow">
              <CardContent className="p-4">
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <Skeleton className="h-4 w-48" />
                    <Skeleton className="h-4 w-16" />
                  </div>
                  <div className="grid grid-cols-3 gap-4">
                    <Skeleton className="h-8 w-full" />
                    <Skeleton className="h-8 w-full" />
                    <Skeleton className="h-8 w-full" />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        ) : trips?.length === 0 ? (
          <Card className="card-shadow">
            <CardContent className="p-8 text-center">
              <Route className="mx-auto h-12 w-12 text-gray-400 mb-4" />
              <p className="text-gray-500">
                {plateFilter ? "Nenhuma viagem encontrada para esta busca" : "Nenhuma viagem registrada ainda"}
              </p>
              <p className="text-sm text-gray-400">
                {plateFilter ? "Tente buscar por outra placa" : "Comece adicionando sua primeira viagem"}
              </p>
            </CardContent>
          </Card>
        ) : (
          trips.map((trip: Trip) => (
            <Card key={trip.id} className="card-shadow">
              <CardContent className="p-4">
                <div className="flex justify-between items-start mb-3">
                  <div className="flex-1">
                    <h3 className="font-medium text-gray-800">
                      {trip.origin} → {trip.destination}
                    </h3>
                    <p className="text-sm text-gray-500">
                      {formatDate(trip.date.toString())}
                    </p>
                  </div>
                  <span className={`px-2 py-1 text-xs rounded-full ${getPurposeColor(trip.purpose)}`}>
                    {trip.purpose}
                  </span>
                </div>
                
                <div className="grid grid-cols-3 gap-4 text-center py-3 border-t border-gray-100">
                  <div>
                    <p className="text-lg font-semibold text-gray-800">
                      {calculateDistance(trip)} km
                    </p>
                    <p className="text-xs text-gray-500">Distância</p>
                  </div>
                  <div>
                    <p className="text-lg font-semibold text-gray-800">
                      {formatCurrency(calculateTotalCost(trip))}
                    </p>
                    <p className="text-xs text-gray-500">Total</p>
                  </div>
                  <div>
                    <p className="text-lg font-semibold text-gray-800">
                      {calculateEfficiency(trip)} km/L
                    </p>
                    <p className="text-xs text-gray-500">Eficiência</p>
                  </div>
                </div>
                
                <div className="flex justify-between items-center pt-3 border-t border-gray-100">
                  <span className="text-sm text-gray-600">
                    Placa: {trip.licensePlate}
                  </span>
                  <div className="flex space-x-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="p-2 text-[#1976D2] hover:bg-[#1976D2]/10"
                    >
                      <Edit2 size={16} />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="p-2 text-[#F44336] hover:bg-[#F44336]/10"
                      onClick={() => handleDeleteTrip(trip.id)}
                      disabled={deleteTripMutation.isPending}
                    >
                      <Trash2 size={16} />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
