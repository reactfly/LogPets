import { apiRequest } from "./queryClient";
import type { User, AuthResponse, LoginCredentials } from "@/types/auth";

export const authAPI = {
  login: async (credentials: LoginCredentials): Promise<AuthResponse> => {
    const response = await apiRequest("POST", "/api/auth/login", credentials);
    return response.json();
  },

  logout: async (): Promise<{ success: boolean }> => {
    const response = await apiRequest("POST", "/api/auth/logout");
    return response.json();
  },

  getCurrentUser: async (): Promise<User> => {
    const response = await apiRequest("GET", "/api/auth/me");
    return response.json();
  },
};
