export interface User {
  id: number;
  username: string;
  email: string;
}

export interface AuthResponse {
  success: boolean;
  user?: User;
  message?: string;
}

export interface LoginCredentials {
  username: string;
  password: string;
}
