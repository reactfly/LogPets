import { Switch, Route } from "wouter";
import { useState } from "react";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import ProtectedRoute from "@/components/protected-route";
import BottomNav from "@/components/bottom-nav";
import Preloader from "@/components/preloader";
import Login from "@/pages/login";
import Dashboard from "@/pages/dashboard";
import TripForm from "@/pages/trip-form";
import TripHistory from "@/pages/trip-history";
import Fines from "@/pages/fines";
import Profile from "@/pages/profile";
import NotFound from "@/pages/not-found";
import { useLocation } from "wouter";

function AppContent() {
  const [location, setLocation] = useLocation();
  const [showTripForm, setShowTripForm] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  const handleNewTrip = () => {
    setShowTripForm(true);
    setLocation("/trip-form");
  };

  const handleLoadingComplete = () => {
    setIsLoading(false);
  };

  const isLoginPage = location === "/login";
  const shouldShowNav = !isLoginPage && location !== "/";

  if (isLoading) {
    return <Preloader onLoadingComplete={handleLoadingComplete} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-teal-50">
      {/* Header */}
      {shouldShowNav && (
        <header className="bg-[#18A192] text-white shadow-lg sticky top-0 z-50">
          <div className="flex items-center justify-between p-4">
            <div className="flex items-center space-x-3">
              <img src="/attached_assets/IMG-20250723-WA0073_1753343353396.jpg" alt="LogPet Logo" className="w-8 h-8 object-contain rounded-full" />
              <h1 className="text-xl font-bold">LogPet</h1>
            </div>
          </div>
        </header>
      )}

      <main className={shouldShowNav ? "pb-32" : ""}>
        <Switch>
          <Route path="/login" component={Login} />
          <Route path="/">
            <ProtectedRoute>
              <Dashboard />
            </ProtectedRoute>
          </Route>
          <Route path="/dashboard">
            <ProtectedRoute>
              <Dashboard />
            </ProtectedRoute>
          </Route>
          <Route path="/trip-form">
            <ProtectedRoute>
              <TripForm />
            </ProtectedRoute>
          </Route>
          <Route path="/history">
            <ProtectedRoute>
              <TripHistory />
            </ProtectedRoute>
          </Route>
          <Route path="/fines">
            <ProtectedRoute>
              <Fines />
            </ProtectedRoute>
          </Route>
          <Route path="/profile">
            <ProtectedRoute>
              <Profile />
            </ProtectedRoute>
          </Route>
          <Route component={NotFound} />
        </Switch>
      </main>

      {/* Bottom Navigation */}
      {shouldShowNav && <BottomNav onNewTrip={handleNewTrip} />}

      {/* Footer */}
      {shouldShowNav && (
        <footer className="bg-[#18A192] text-white py-3 px-4 text-center text-xs fixed bottom-0 left-0 right-0 z-40 mt-2">
          <p>Copyright 2026 - Todos os direitos reservados para LOGPETS | By: GROWMONEY DIGITAL</p>
        </footer>
      )}
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <AppContent />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
