import { pgTable, text, serial, integer, boolean, timestamp, decimal, varchar } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const trips = pgTable("trips", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  date: timestamp("date").notNull(),
  licensePlate: varchar("license_plate", { length: 10 }).notNull(),
  origin: text("origin").notNull(),
  destination: text("destination").notNull(),
  initialKm: integer("initial_km").notNull(),
  finalKm: integer("final_km").notNull(),
  purpose: text("purpose").notNull(),
  fuelCost: decimal("fuel_cost", { precision: 10, scale: 2 }).default("0"),
  tollCost: decimal("toll_cost", { precision: 10, scale: 2 }).default("0"),
  parkingCost: decimal("parking_cost", { precision: 10, scale: 2 }).default("0"),
  otherCosts: decimal("other_costs", { precision: 10, scale: 2 }).default("0"),
  observations: text("observations"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const fines = pgTable("fines", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  infringementDate: timestamp("infringement_date").notNull(),
  licensePlate: varchar("license_plate", { length: 10 }).notNull(),
  infractionType: text("infraction_type").notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  points: integer("points").default(0),
  location: text("location").notNull(),
  status: text("status").notNull().default("pending"), // pending, paid, contested
  attachmentPath: text("attachment_path"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const usersRelations = relations(users, ({ many }) => ({
  trips: many(trips),
  fines: many(fines),
}));

export const tripsRelations = relations(trips, ({ one }) => ({
  user: one(users, {
    fields: [trips.userId],
    references: [users.id],
  }),
}));

export const finesRelations = relations(fines, ({ one }) => ({
  user: one(users, {
    fields: [fines.userId],
    references: [users.id],
  }),
}));

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
});

export const insertTripSchema = createInsertSchema(trips).omit({
  id: true,
  userId: true,
  createdAt: true,
}).extend({
  date: z.union([z.string(), z.date()]).transform((val) => {
    if (typeof val === 'string') {
      return new Date(val);
    }
    return val;
  }),
  fuelCost: z.union([z.string(), z.number()]).transform((val) => val.toString()),
  tollCost: z.union([z.string(), z.number()]).transform((val) => val.toString()),
  parkingCost: z.union([z.string(), z.number()]).transform((val) => val.toString()),
  otherCosts: z.union([z.string(), z.number()]).transform((val) => val.toString()),
});

export const insertFineSchema = createInsertSchema(fines).omit({
  id: true,
  userId: true,
  createdAt: true,
}).extend({
  infringementDate: z.union([z.string(), z.date()]).transform((val) => {
    if (typeof val === 'string') {
      return new Date(val);
    }
    return val;
  }),
  amount: z.union([z.string(), z.number()]).transform((val) => val.toString()),
  points: z.union([z.string(), z.number()]).transform((val) => {
    if (typeof val === 'string') {
      return parseInt(val) || 0;
    }
    return val;
  }),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertTrip = z.infer<typeof insertTripSchema>;
export type Trip = typeof trips.$inferSelect;
export type InsertFine = z.infer<typeof insertFineSchema>;
export type Fine = typeof fines.$inferSelect;
