import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Construction, Fuel, AlertTriangle, Gauge } from "lucide-react";
import type { Trip } from "@shared/schema";

export default function Dashboard() {
  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/stats"],
  });

  const { data: trips, isLoading: tripsLoading } = useQuery({
    queryKey: ["/api/trips"],
  });

  const recentTrips = (trips as Trip[] || []).slice(0, 3);

  const formatCurrency = (value: string | number) => {
    return `R$ ${parseFloat(value.toString()).toLocaleString('pt-BR', { 
      minimumFractionDigits: 2,
      maximumFractionDigits: 2 
    })}`;
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('pt-BR');
  };

  const calculateDistance = (trip: Trip) => {
    return trip.finalKm - trip.initialKm;
  };

  const calculateTotalCost = (trip: Trip) => {
    return parseFloat(trip.fuelCost || "0") + 
           parseFloat(trip.tollCost || "0") + 
           parseFloat(trip.parkingCost || "0") + 
           parseFloat(trip.otherCosts || "0");
  };

  const getPurposeColor = (purpose: string) => {
    switch (purpose.toLowerCase()) {
      case 'trabalho': return 'bg-[#18A192]/10 text-[#18A192]';
      case 'pessoal': return 'bg-[#1976D2]/10 text-[#1976D2]';
      case 'reunião': return 'bg-[#FF6F00]/10 text-[#FF6F00]';
      default: return 'bg-gray-100 text-gray-600';
    }
  };

  return (
    <div className="p-4 pb-20">
      {/* Stats Cards */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <Card className="card-shadow">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-[#18A192]/10 rounded-lg flex items-center justify-center">
                <Construction className="text-[#18A192]" size={20} />
              </div>
              <div>
                {statsLoading ? (
                  <Skeleton className="h-6 w-8 mb-1" />
                ) : (
                  <p className="text-2xl font-bold text-gray-800">
                    {(stats as any)?.totalTrips || 0}
                  </p>
                )}
                <p className="text-sm text-gray-500">Viagens</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="card-shadow">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-[#1976D2]/10 rounded-lg flex items-center justify-center">
                <Fuel className="text-[#1976D2]" size={20} />
              </div>
              <div>
                {statsLoading ? (
                  <Skeleton className="h-6 w-16 mb-1" />
                ) : (
                  <p className="text-2xl font-bold text-gray-800">
                    {formatCurrency((stats as any)?.totalCosts || "0")}
                  </p>
                )}
                <p className="text-sm text-gray-500">Total Gastos</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="card-shadow">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-[#FF9800]/10 rounded-lg flex items-center justify-center">
                <AlertTriangle className="text-[#FF9800]" size={20} />
              </div>
              <div>
                {statsLoading ? (
                  <Skeleton className="h-6 w-4 mb-1" />
                ) : (
                  <p className="text-2xl font-bold text-gray-800">
                    {(stats as any)?.totalFines || 0}
                  </p>
                )}
                <p className="text-sm text-gray-500">Multas</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="card-shadow">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-[#4CAF50]/10 rounded-lg flex items-center justify-center">
                <Gauge className="text-[#4CAF50]" size={20} />
              </div>
              <div>
                {statsLoading ? (
                  <Skeleton className="h-6 w-8 mb-1" />
                ) : (
                  <p className="text-2xl font-bold text-gray-800">
                    {(stats as any)?.avgEfficiency || "0"}
                  </p>
                )}
                <p className="text-sm text-gray-500">km/L médio</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Trips */}
      <Card className="card-shadow mb-6">
        <div className="p-4 border-b border-gray-100">
          <h2 className="text-lg font-semibold text-gray-800">Viagens Recentes</h2>
        </div>
        
        {tripsLoading ? (
          <div className="p-4 space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="space-y-2">
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-3 w-1/2" />
                <Skeleton className="h-3 w-1/4" />
              </div>
            ))}
          </div>
        ) : recentTrips.length === 0 ? (
          <div className="p-8 text-center">
            <Construction className="mx-auto h-12 w-12 text-gray-400 mb-4" />
            <p className="text-gray-500">Nenhuma viagem registrada ainda</p>
            <p className="text-sm text-gray-400">Comece adicionando sua primeira viagem</p>
          </div>
        ) : (
          recentTrips.map((trip) => (
            <div key={trip.id} className="p-4 border-b border-gray-50 last:border-b-0">
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <div className="flex items-center space-x-2">
                    <span className="text-sm font-medium text-gray-800">
                      {trip.origin} → {trip.destination}
                    </span>
                    <span className={`px-2 py-1 text-xs rounded-full ${getPurposeColor(trip.purpose)}`}>
                      {trip.purpose}
                    </span>
                  </div>
                  <p className="text-sm text-gray-500 mt-1">
                    {formatDate(trip.date.toString())}
                  </p>
                  <p className="text-xs text-gray-400">
                    Placa: {trip.licensePlate}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-semibold text-gray-800">
                    {formatCurrency(calculateTotalCost(trip))}
                  </p>
                  <p className="text-xs text-gray-500">
                    {calculateDistance(trip)} km
                  </p>
                </div>
              </div>
            </div>
          ))
        )}
      </Card>
    </div>
  );
}
