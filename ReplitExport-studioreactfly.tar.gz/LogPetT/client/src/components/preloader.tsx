import { useEffect, useState } from "react";

interface PreloaderProps {
  onLoadingComplete: () => void;
}

export default function Preloader({ onLoadingComplete }: PreloaderProps) {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const timer = setTimeout(() => {
      setProgress(100);
      setTimeout(() => {
        onLoadingComplete();
      }, 500);
    }, 2000);

    // Simulate loading progress
    const progressTimer = setInterval(() => {
      setProgress(prev => {
        if (prev >= 90) return prev;
        return prev + Math.random() * 10;
      });
    }, 100);

    return () => {
      clearTimeout(timer);
      clearInterval(progressTimer);
    };
  }, [onLoadingComplete]);

  return (
    <div className="fixed inset-0 bg-gradient-to-br from-[#18A192] via-[#20B2AA] to-[#48D1CC] flex flex-col items-center justify-center z-50">
      {/* Logo Container */}
      <div className="relative mb-8">
        {/* Animated circle background */}
        <div className="w-32 h-32 rounded-full bg-white/20 absolute animate-ping"></div>
        <div className="w-32 h-32 rounded-full bg-white/30 absolute animate-pulse"></div>
        
        {/* Logo */}
        <div className="relative w-32 h-32 rounded-full bg-white shadow-2xl flex items-center justify-center overflow-hidden">
          <img 
            src="/attached_assets/IMG-20250723-WA0073_1753343353396.jpg" 
            alt="LogPet Logo" 
            className="w-28 h-28 object-contain rounded-full"
          />
        </div>
      </div>

      {/* Brand Text */}
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold text-white mb-2 tracking-wide">
          LogPet
        </h1>
        <p className="text-teal-100 text-lg font-medium">
          Transporte de Animais
        </p>
      </div>

      {/* Loading Progress */}
      <div className="w-64 mb-4">
        <div className="w-full bg-white/20 rounded-full h-2">
          <div 
            className="bg-white h-2 rounded-full transition-all duration-300 ease-out"
            style={{ width: `${progress}%` }}
          ></div>
        </div>
      </div>

      {/* Loading Text */}
      <div className="text-white/80 text-sm">
        <div className="flex items-center space-x-1">
          <span>Carregando</span>
          <div className="flex space-x-1">
            <div className="w-1 h-1 bg-white rounded-full animate-bounce"></div>
            <div className="w-1 h-1 bg-white rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
            <div className="w-1 h-1 bg-white rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
          </div>
        </div>
      </div>

      {/* Floating particles animation */}
      <div className="absolute inset-0 pointer-events-none">
        {Array.from({ length: 6 }).map((_, i) => (
          <div
            key={i}
            className="absolute w-2 h-2 bg-white/30 rounded-full animate-float"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`,
              animationDuration: `${3 + Math.random() * 2}s`
            }}
          ></div>
        ))}
      </div>
    </div>
  );
}