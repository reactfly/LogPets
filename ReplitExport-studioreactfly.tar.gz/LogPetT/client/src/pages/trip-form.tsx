import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertTripSchema } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { z } from "zod";

const tripFormSchema = z.object({
  date: z.string().min(1, "Data é obrigatória"),
  licensePlate: z.string().min(1, "Placa é obrigatória"),
  origin: z.string().min(1, "Origem é obrigatória"),
  destination: z.string().min(1, "Destino é obrigatório"),
  initialKm: z.number().min(0, "KM inicial deve ser positivo"),
  finalKm: z.number().min(0, "KM final deve ser positivo"),
  purpose: z.string().min(1, "Finalidade é obrigatória"),
  fuelCost: z.string().default("0"),
  tollCost: z.string().default("0"),
  parkingCost: z.string().default("0"),
  otherCosts: z.string().default("0"),
  observations: z.string().optional(),
});

type TripFormData = z.infer<typeof tripFormSchema>;

export default function TripForm() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<TripFormData>({
    resolver: zodResolver(tripFormSchema),
    defaultValues: {
      date: new Date().toISOString().split('T')[0],
      licensePlate: "",
      origin: "",
      destination: "",
      initialKm: 0,
      finalKm: 0,
      purpose: "",
      fuelCost: "0",
      tollCost: "0",
      parkingCost: "0",
      otherCosts: "0",
      observations: "",
    },
  });

  const createTripMutation = useMutation({
    mutationFn: async (data: TripFormData) => {
      const response = await apiRequest("POST", "/api/trips", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/trips"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({
        title: "Sucesso",
        description: "Viagem registrada com sucesso!",
      });
      setLocation("/dashboard");
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Erro ao registrar viagem",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: TripFormData) => {
    createTripMutation.mutate(data);
  };

  return (
    <div className="p-4 pb-20">
      <Card className="card-shadow">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-gray-800">Nova Viagem</CardTitle>
        </CardHeader>
        
        <CardContent>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="date">Data</Label>
                <Input
                  id="date"
                  type="date"
                  {...form.register("date")}
                  className="mt-2"
                />
                {form.formState.errors.date && (
                  <p className="text-red-500 text-sm mt-1">{form.formState.errors.date.message}</p>
                )}
              </div>
              <div>
                <Label htmlFor="licensePlate">Placa</Label>
                <Input
                  id="licensePlate"
                  placeholder="ABC-1234"
                  {...form.register("licensePlate")}
                  className="mt-2"
                />
                {form.formState.errors.licensePlate && (
                  <p className="text-red-500 text-sm mt-1">{form.formState.errors.licensePlate.message}</p>
                )}
              </div>
            </div>

            <div>
              <Label htmlFor="origin">Origem</Label>
              <Input
                id="origin"
                placeholder="Cidade de origem"
                {...form.register("origin")}
                className="mt-2"
              />
              {form.formState.errors.origin && (
                <p className="text-red-500 text-sm mt-1">{form.formState.errors.origin.message}</p>
              )}
            </div>

            <div>
              <Label htmlFor="destination">Destino</Label>
              <Input
                id="destination"
                placeholder="Cidade de destino"
                {...form.register("destination")}
                className="mt-2"
              />
              {form.formState.errors.destination && (
                <p className="text-red-500 text-sm mt-1">{form.formState.errors.destination.message}</p>
              )}
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="initialKm">KM Inicial</Label>
                <Input
                  id="initialKm"
                  type="number"
                  placeholder="0"
                  {...form.register("initialKm", { 
                    valueAsNumber: true,
                    required: "KM inicial é obrigatório" 
                  })}
                  className="mt-2"
                />
                {form.formState.errors.initialKm && (
                  <p className="text-red-500 text-sm mt-1">{form.formState.errors.initialKm.message}</p>
                )}
              </div>
              <div>
                <Label htmlFor="finalKm">KM Final</Label>
                <Input
                  id="finalKm"
                  type="number"
                  placeholder="0"
                  {...form.register("finalKm", { 
                    valueAsNumber: true,
                    required: "KM final é obrigatório" 
                  })}
                  className="mt-2"
                />
                {form.formState.errors.finalKm && (
                  <p className="text-red-500 text-sm mt-1">{form.formState.errors.finalKm.message}</p>
                )}
              </div>
            </div>

            <div>
              <Label htmlFor="purpose">Finalidade</Label>
              <Select onValueChange={(value) => form.setValue("purpose", value)}>
                <SelectTrigger className="mt-2">
                  <SelectValue placeholder="Selecione a finalidade" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Trabalho">Trabalho</SelectItem>
                  <SelectItem value="Pessoal">Pessoal</SelectItem>
                  <SelectItem value="Reunião">Reunião</SelectItem>
                  <SelectItem value="Outros">Outros</SelectItem>
                </SelectContent>
              </Select>
              {form.formState.errors.purpose && (
                <p className="text-red-500 text-sm mt-1">{form.formState.errors.purpose.message}</p>
              )}
            </div>

            {/* Cost Section */}
            <div className="border-t border-gray-100 pt-4">
              <h3 className="text-md font-medium text-gray-700 mb-3">Custos da Viagem</h3>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="fuelCost">Combustível (R$)</Label>
                  <Input
                    id="fuelCost"
                    type="number"
                    step="0.01"
                    placeholder="0,00"
                    {...form.register("fuelCost")}
                    className="mt-2"
                  />
                </div>
                <div>
                  <Label htmlFor="tollCost">Pedágio (R$)</Label>
                  <Input
                    id="tollCost"
                    type="number"
                    step="0.01"
                    placeholder="0,00"
                    {...form.register("tollCost")}
                    className="mt-2"
                  />
                </div>
                <div>
                  <Label htmlFor="parkingCost">Estacionamento (R$)</Label>
                  <Input
                    id="parkingCost"
                    type="number"
                    step="0.01"
                    placeholder="0,00"
                    {...form.register("parkingCost")}
                    className="mt-2"
                  />
                </div>
                <div>
                  <Label htmlFor="otherCosts">Outros (R$)</Label>
                  <Input
                    id="otherCosts"
                    type="number"
                    step="0.01"
                    placeholder="0,00"
                    {...form.register("otherCosts")}
                    className="mt-2"
                  />
                </div>
              </div>
            </div>

            <div>
              <Label htmlFor="observations">Observações</Label>
              <Textarea
                id="observations"
                rows={3}
                placeholder="Observações adicionais..."
                {...form.register("observations")}
                className="mt-2 resize-none"
              />
            </div>

            <Button
              type="submit"
              className="w-full bg-[#18A192] hover:bg-[#138A7E] text-white py-3"
              disabled={createTripMutation.isPending}
            >
              {createTripMutation.isPending ? "Salvando..." : "Salvar Viagem"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
