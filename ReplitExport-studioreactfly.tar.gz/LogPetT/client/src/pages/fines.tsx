import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertFineSchema } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { AlertTriangle, Upload, CloudUpload } from "lucide-react";
import { z } from "zod";
import type { Fine } from "@shared/schema";

const fineFormSchema = z.object({
  infringementDate: z.string().min(1, "Data é obrigatória"),
  licensePlate: z.string().min(1, "Placa é obrigatória"),
  infractionType: z.string().min(1, "Tipo de infração é obrigatório"),
  amount: z.string().min(1, "Valor é obrigatório"),
  points: z.number().min(0, "Pontos devem ser positivos"),
  location: z.string().min(1, "Local é obrigatório"),
  status: z.string().default("pending"),
  attachmentPath: z.string().optional(),
});

type FineFormData = z.infer<typeof fineFormSchema>;

export default function Fines() {
  const [attachmentFile, setAttachmentFile] = useState<File | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<FineFormData>({
    resolver: zodResolver(fineFormSchema),
    defaultValues: {
      infringementDate: new Date().toISOString().split('T')[0],
      licensePlate: "",
      infractionType: "",
      amount: "",
      points: 0,
      location: "",
      status: "pending",
      attachmentPath: "",
    },
  });

  const { data: fines, isLoading } = useQuery({
    queryKey: ["/api/fines"],
  });

  const createFineMutation = useMutation({
    mutationFn: async (data: { formData: FineFormData; file?: File }) => {
      const formData = new FormData();
      
      // Add form fields
      Object.entries(data.formData).forEach(([key, value]) => {
        if (key === 'infringementDate') {
          formData.append(key, new Date(value as string).toISOString());
        } else {
          formData.append(key, value?.toString() || '');
        }
      });
      
      // Add file if present
      if (data.file) {
        formData.append('attachment', data.file);
      }

      const response = await fetch('/api/fines', {
        method: 'POST',
        body: formData,
        credentials: 'include',
      });

      if (!response.ok) {
        throw new Error('Failed to create fine');
      }

      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/fines"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      form.reset();
      setAttachmentFile(null);
      toast({
        title: "Sucesso",
        description: "Multa registrada com sucesso!",
      });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Erro ao registrar multa",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: FineFormData) => {
    createFineMutation.mutate({ formData: data, file: attachmentFile || undefined });
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Check file size (5MB limit)
      if (file.size > 5 * 1024 * 1024) {
        toast({
          title: "Arquivo muito grande",
          description: "O arquivo deve ter no máximo 5MB",
          variant: "destructive",
        });
        return;
      }
      setAttachmentFile(file);
    }
  };

  const formatCurrency = (value: string | number) => {
    return `R$ ${parseFloat(value.toString()).toLocaleString('pt-BR', { 
      minimumFractionDigits: 2,
      maximumFractionDigits: 2 
    })}`;
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('pt-BR');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'paid': return 'bg-[#4CAF50]/10 text-[#4CAF50]';
      case 'contested': return 'bg-[#FF9800]/10 text-[#FF9800]';
      default: return 'bg-[#F44336]/10 text-[#F44336]';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'paid': return 'Pago';
      case 'contested': return 'Contestado';
      default: return 'Pendente';
    }
  };

  return (
    <div className="p-4 pb-20">
      {/* Fine Registration Form */}
      <Card className="card-shadow mb-4">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-gray-800">Registrar Multa</CardTitle>
        </CardHeader>
        
        <CardContent>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="infringementDate">Data da Infração</Label>
                <Input
                  id="infringementDate"
                  type="date"
                  {...form.register("infringementDate")}
                  className="mt-2"
                />
                {form.formState.errors.infringementDate && (
                  <p className="text-red-500 text-sm mt-1">{form.formState.errors.infringementDate.message}</p>
                )}
              </div>
              <div>
                <Label htmlFor="licensePlate">Placa</Label>
                <Input
                  id="licensePlate"
                  placeholder="ABC-1234"
                  {...form.register("licensePlate")}
                  className="mt-2"
                />
                {form.formState.errors.licensePlate && (
                  <p className="text-red-500 text-sm mt-1">{form.formState.errors.licensePlate.message}</p>
                )}
              </div>
            </div>

            <div>
              <Label htmlFor="infractionType">Tipo de Infração</Label>
              <Select onValueChange={(value) => form.setValue("infractionType", value)}>
                <SelectTrigger className="mt-2">
                  <SelectValue placeholder="Selecione o tipo" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Excesso de velocidade">Excesso de velocidade</SelectItem>
                  <SelectItem value="Estacionamento irregular">Estacionamento irregular</SelectItem>
                  <SelectItem value="Avanço de sinal">Avanço de sinal</SelectItem>
                  <SelectItem value="Outros">Outros</SelectItem>
                </SelectContent>
              </Select>
              {form.formState.errors.infractionType && (
                <p className="text-red-500 text-sm mt-1">{form.formState.errors.infractionType.message}</p>
              )}
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="amount">Valor (R$)</Label>
                <Input
                  id="amount"
                  type="number"
                  step="0.01"
                  placeholder="0,00"
                  {...form.register("amount")}
                  className="mt-2"
                />
                {form.formState.errors.amount && (
                  <p className="text-red-500 text-sm mt-1">{form.formState.errors.amount.message}</p>
                )}
              </div>
              <div>
                <Label htmlFor="points">Pontos CNH</Label>
                <Input
                  id="points"
                  type="number"
                  placeholder="0"
                  {...form.register("points", { 
                    valueAsNumber: true,
                    required: "Pontos são obrigatórios",
                    min: { value: 0, message: "Pontos devem ser positivos" },
                    max: { value: 20, message: "Máximo 20 pontos" }
                  })}
                  className="mt-2"
                />
                {form.formState.errors.points && (
                  <p className="text-red-500 text-sm mt-1">{form.formState.errors.points.message}</p>
                )}
              </div>
            </div>

            <div>
              <Label htmlFor="location">Local da Infração</Label>
              <Input
                id="location"
                placeholder="Endereço ou local"
                {...form.register("location")}
                className="mt-2"
              />
              {form.formState.errors.location && (
                <p className="text-red-500 text-sm mt-1">{form.formState.errors.location.message}</p>
              )}
            </div>

            {/* Media Upload Section */}
            <div className="border-t border-gray-100 pt-4">
              <Label className="block text-sm font-medium text-gray-700 mb-2">Anexar Comprovante</Label>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                {attachmentFile ? (
                  <div className="space-y-2">
                    <Upload className="mx-auto h-8 w-8 text-green-500" />
                    <p className="text-sm text-gray-700">{attachmentFile.name}</p>
                    <p className="text-xs text-gray-500">
                      {(attachmentFile.size / 1024 / 1024).toFixed(2)} MB
                    </p>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => setAttachmentFile(null)}
                    >
                      Remover
                    </Button>
                  </div>
                ) : (
                  <>
                    <CloudUpload className="mx-auto h-12 w-12 text-gray-400 mb-2" />
                    <p className="text-sm text-gray-500">Toque para selecionar arquivo</p>
                    <p className="text-xs text-gray-400 mt-1">PDF, JPG, PNG até 5MB</p>
                    <input
                      type="file"
                      accept=".pdf,.jpg,.jpeg,.png"
                      onChange={handleFileChange}
                      className="hidden"
                      id="file-upload"
                    />
                    <Label
                      htmlFor="file-upload"
                      className="inline-block mt-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg cursor-pointer hover:bg-gray-200"
                    >
                      Selecionar arquivo
                    </Label>
                  </>
                )}
              </div>
            </div>

            <Button
              type="submit"
              className="w-full bg-[#FF9800] hover:bg-orange-600 text-white py-3"
              disabled={createFineMutation.isPending}
            >
              {createFineMutation.isPending ? "Registrando..." : "Registrar Multa"}
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* Fine History */}
      <Card className="card-shadow">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-gray-800">Histórico de Multas</CardTitle>
        </CardHeader>
        
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-4 space-y-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="space-y-2">
                  <Skeleton className="h-4 w-3/4" />
                  <Skeleton className="h-3 w-1/2" />
                  <Skeleton className="h-3 w-1/4" />
                </div>
              ))}
            </div>
          ) : (fines as Fine[] || []).length === 0 ? (
            <div className="p-8 text-center">
              <AlertTriangle className="mx-auto h-12 w-12 text-gray-400 mb-4" />
              <p className="text-gray-500">Nenhuma multa registrada ainda</p>
              <p className="text-sm text-gray-400">Registre suas multas para acompanhar os custos</p>
            </div>
          ) : (
            <div className="divide-y divide-gray-100">
              {(fines as Fine[] || []).map((fine: Fine) => (
                <div key={fine.id} className="p-4">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2">
                        <span className="text-sm font-medium text-gray-800">
                          {fine.infractionType}
                        </span>
                        {(fine.points || 0) > 0 && (
                          <span className="px-2 py-1 bg-[#FF9800]/10 text-[#FF9800] text-xs rounded-full">
                            {fine.points} pontos
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-gray-500 mt-1">
                        {formatDate(fine.infringementDate.toString())}
                      </p>
                      <p className="text-xs text-gray-400">{fine.location}</p>
                      <p className="text-xs text-gray-400">Placa: {fine.licensePlate}</p>
                    </div>
                    <div className="text-right">
                      <p className={`text-sm font-semibold ${
                        fine.status === 'paid' ? 'text-[#4CAF50]' : 'text-[#F44336]'
                      }`}>
                        {formatCurrency(fine.amount)}
                      </p>
                      <span className={`inline-block px-2 py-1 text-xs rounded-full mt-1 ${getStatusColor(fine.status)}`}>
                        {getStatusText(fine.status)}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
