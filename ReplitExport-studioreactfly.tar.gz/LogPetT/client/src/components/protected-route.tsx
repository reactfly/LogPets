import { useQuery } from "@tanstack/react-query";
import { authAPI } from "@/lib/auth";
import { useLocation } from "wouter";
import { useEffect } from "react";

interface ProtectedRouteProps {
  children: React.ReactNode;
}

export default function ProtectedRoute({ children }: ProtectedRouteProps) {
  const [, setLocation] = useLocation();
  
  const { data: user, isLoading, error } = useQuery({
    queryKey: ["/api/auth/me"],
    queryFn: authAPI.getCurrentUser,
    retry: false,
  });

  useEffect(() => {
    if (error && !isLoading) {
      setLocation("/login");
    }
  }, [error, isLoading, setLocation]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#18A192] flex flex-col items-center justify-center">
        <div className="text-center">
          <div className="w-24 h-24 mx-auto bg-white rounded-full flex items-center justify-center shadow-lg mb-8">
            <img src="/attached_assets/IMG-20250723-WA0073_1753342216285.jpg" alt="LogPet Logo" className="w-20 h-20 object-contain rounded-full" />
          </div>
          <h1 className="text-4xl font-bold text-white mb-2">LogPet</h1>
          <p className="text-teal-100 text-lg">Transporte de Animais</p>
          <div className="mt-8">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-white mx-auto"></div>
          </div>
          <p className="text-teal-100 text-sm mt-4">Carregando...</p>
        </div>
      </div>
    );
  }

  if (error || !user) {
    return null;
  }

  return <>{children}</>;
}
