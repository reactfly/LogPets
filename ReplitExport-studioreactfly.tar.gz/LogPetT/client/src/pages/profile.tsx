import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { authAPI } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { User, Download, Settings, Info, LogOut, Car } from "lucide-react";

export default function Profile() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const logoutMutation = useMutation({
    mutationFn: authAPI.logout,
    onSuccess: () => {
      queryClient.clear();
      setLocation("/login");
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Erro ao fazer logout",
        variant: "destructive",
      });
    },
  });

  const handleLogout = () => {
    if (window.confirm("Deseja realmente sair?")) {
      logoutMutation.mutate();
    }
  };

  const handleExportData = () => {
    toast({
      title: "Funcionalidade em desenvolvimento",
      description: "A exportação de dados será implementada em breve",
    });
  };

  const handleSettings = () => {
    toast({
      title: "Funcionalidade em desenvolvimento",
      description: "As configurações serão implementadas em breve",
    });
  };

  const handleAbout = () => {
    toast({
      title: "LogPet v1.0.0",
      description: "Gerenciador de viagens desenvolvido para controle de custos e histórico",
    });
  };

  return (
    <div className="p-4 pb-20">
      {/* User Profile Card */}
      <Card className="card-shadow mb-4">
        <CardContent className="p-6 text-center border-b border-gray-100">
          <div className="w-20 h-20 mx-auto bg-[#18A192]/10 rounded-full flex items-center justify-center mb-4">
            <img src="/attached_assets/IMG-20250723-WA0073_1753343353396.jpg" alt="LogPet Logo" className="w-16 h-16 object-contain rounded-full" />
          </div>
          <h2 className="text-xl font-semibold text-gray-800">Administrador</h2>
          <p className="text-sm text-gray-500">admin@logpet.com</p>
        </CardContent>

        {/* Menu Items */}
        <CardContent className="p-4 space-y-3">
          <Button
            variant="ghost"
            className="w-full flex items-center justify-between p-3 hover:bg-gray-50 rounded-lg h-auto"
            onClick={handleExportData}
          >
            <div className="flex items-center space-x-3">
              <Download className="text-[#18A192]" size={20} />
              <span className="text-gray-700">Exportar Dados</span>
            </div>
            <i className="fas fa-chevron-right text-gray-400"></i>
          </Button>

          <Button
            variant="ghost"
            className="w-full flex items-center justify-between p-3 hover:bg-gray-50 rounded-lg h-auto"
            onClick={handleSettings}
          >
            <div className="flex items-center space-x-3">
              <Settings className="text-[#18A192]" size={20} />
              <span className="text-gray-700">Configurações</span>
            </div>
            <i className="fas fa-chevron-right text-gray-400"></i>
          </Button>

          <Button
            variant="ghost"
            className="w-full flex items-center justify-between p-3 hover:bg-gray-50 rounded-lg h-auto"
            onClick={handleAbout}
          >
            <div className="flex items-center space-x-3">
              <Info className="text-[#18A192]" size={20} />
              <span className="text-gray-700">Sobre o App</span>
            </div>
            <i className="fas fa-chevron-right text-gray-400"></i>
          </Button>

          <Button
            variant="ghost"
            className="w-full flex items-center justify-between p-3 hover:bg-gray-50 rounded-lg h-auto text-[#F44336]"
            onClick={handleLogout}
            disabled={logoutMutation.isPending}
          >
            <div className="flex items-center space-x-3">
              <LogOut size={20} />
              <span>{logoutMutation.isPending ? "Saindo..." : "Sair"}</span>
            </div>
            <i className="fas fa-chevron-right text-gray-400"></i>
          </Button>
        </CardContent>
      </Card>

      {/* App Info */}
      <Card className="card-shadow text-center">
        <CardContent className="p-4">
          <div className="w-12 h-12 mx-auto bg-[#18A192]/10 rounded-full flex items-center justify-center mb-3">
            <img src="/attached_assets/IMG-20250723-WA0073_1753343353396.jpg" alt="LogPet Logo" className="w-10 h-10 object-contain rounded-full" />
          </div>
          <h3 className="font-semibold text-gray-800">LogPet</h3>
          <p className="text-sm text-gray-500">Versão 1.0.0</p>
          <p className="text-xs text-gray-400 mt-2">Transporte de Animais</p>
        </CardContent>
      </Card>
    </div>
  );
}
