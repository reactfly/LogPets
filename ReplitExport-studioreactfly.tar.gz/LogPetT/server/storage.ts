import { users, trips, fines, type User, type InsertUser, type Trip, type InsertTrip, type Fine, type InsertFine } from "@shared/schema";
import { db } from "./db";
import { eq, desc, like, and } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Trip operations
  createTrip(trip: InsertTrip & { userId: number }): Promise<Trip>;
  getTripsByUser(userId: number): Promise<Trip[]>;
  getTripsByPlate(userId: number, licensePlate: string): Promise<Trip[]>;
  getTrip(id: number, userId: number): Promise<Trip | undefined>;
  updateTrip(id: number, userId: number, trip: Partial<InsertTrip>): Promise<Trip | undefined>;
  deleteTrip(id: number, userId: number): Promise<boolean>;

  // Fine operations
  createFine(fine: InsertFine & { userId: number }): Promise<Fine>;
  getFinesByUser(userId: number): Promise<Fine[]>;
  getFinesByPlate(userId: number, licensePlate: string): Promise<Fine[]>;
  getFine(id: number, userId: number): Promise<Fine | undefined>;
  updateFine(id: number, userId: number, fine: Partial<InsertFine>): Promise<Fine | undefined>;
  deleteFine(id: number, userId: number): Promise<boolean>;

  // Statistics
  getTripStats(userId: number): Promise<{
    totalTrips: number;
    totalCosts: string;
    totalFines: number;
    avgEfficiency: string;
  }>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async createTrip(trip: InsertTrip & { userId: number }): Promise<Trip> {
    const [newTrip] = await db
      .insert(trips)
      .values(trip)
      .returning();
    return newTrip;
  }

  async getTripsByUser(userId: number): Promise<Trip[]> {
    return await db
      .select()
      .from(trips)
      .where(eq(trips.userId, userId))
      .orderBy(desc(trips.date));
  }

  async getTripsByPlate(userId: number, licensePlate: string): Promise<Trip[]> {
    return await db
      .select()
      .from(trips)
      .where(and(eq(trips.userId, userId), like(trips.licensePlate, `%${licensePlate}%`)))
      .orderBy(desc(trips.date));
  }

  async getTrip(id: number, userId: number): Promise<Trip | undefined> {
    const [trip] = await db
      .select()
      .from(trips)
      .where(and(eq(trips.id, id), eq(trips.userId, userId)));
    return trip || undefined;
  }

  async updateTrip(id: number, userId: number, trip: Partial<InsertTrip>): Promise<Trip | undefined> {
    const [updatedTrip] = await db
      .update(trips)
      .set(trip)
      .where(and(eq(trips.id, id), eq(trips.userId, userId)))
      .returning();
    return updatedTrip || undefined;
  }

  async deleteTrip(id: number, userId: number): Promise<boolean> {
    const result = await db
      .delete(trips)
      .where(and(eq(trips.id, id), eq(trips.userId, userId)));
    return (result.rowCount || 0) > 0;
  }

  async createFine(fine: InsertFine & { userId: number }): Promise<Fine> {
    const [newFine] = await db
      .insert(fines)
      .values(fine)
      .returning();
    return newFine;
  }

  async getFinesByUser(userId: number): Promise<Fine[]> {
    return await db
      .select()
      .from(fines)
      .where(eq(fines.userId, userId))
      .orderBy(desc(fines.infringementDate));
  }

  async getFinesByPlate(userId: number, licensePlate: string): Promise<Fine[]> {
    return await db
      .select()
      .from(fines)
      .where(and(eq(fines.userId, userId), like(fines.licensePlate, `%${licensePlate}%`)))
      .orderBy(desc(fines.infringementDate));
  }

  async getFine(id: number, userId: number): Promise<Fine | undefined> {
    const [fine] = await db
      .select()
      .from(fines)
      .where(and(eq(fines.id, id), eq(fines.userId, userId)));
    return fine || undefined;
  }

  async updateFine(id: number, userId: number, fine: Partial<InsertFine>): Promise<Fine | undefined> {
    const [updatedFine] = await db
      .update(fines)
      .set(fine)
      .where(and(eq(fines.id, id), eq(fines.userId, userId)))
      .returning();
    return updatedFine || undefined;
  }

  async deleteFine(id: number, userId: number): Promise<boolean> {
    const result = await db
      .delete(fines)
      .where(and(eq(fines.id, id), eq(fines.userId, userId)));
    return (result.rowCount || 0) > 0;
  }

  async getTripStats(userId: number): Promise<{
    totalTrips: number;
    totalCosts: string;
    totalFines: number;
    avgEfficiency: string;
  }> {
    const userTrips = await this.getTripsByUser(userId);
    const userFines = await this.getFinesByUser(userId);

    const totalTrips = userTrips.length;
    const totalFines = userFines.length;
    
    const totalCosts = userTrips.reduce((sum, trip) => {
      return sum + 
        parseFloat(trip.fuelCost || "0") + 
        parseFloat(trip.tollCost || "0") + 
        parseFloat(trip.parkingCost || "0") + 
        parseFloat(trip.otherCosts || "0");
    }, 0);

    let avgEfficiency = "0";
    if (totalTrips > 0) {
      const totalDistance = userTrips.reduce((sum, trip) => sum + (trip.finalKm - trip.initialKm), 0);
      const totalFuel = userTrips.reduce((sum, trip) => sum + parseFloat(trip.fuelCost || "0"), 0);
      if (totalFuel > 0) {
        // Assuming average fuel price of R$ 5.50 per liter
        const avgFuelPrice = 5.50;
        const totalLiters = totalFuel / avgFuelPrice;
        avgEfficiency = (totalDistance / totalLiters).toFixed(1);
      }
    }

    return {
      totalTrips,
      totalCosts: totalCosts.toFixed(2),
      totalFines,
      avgEfficiency,
    };
  }
}

export const storage = new DatabaseStorage();
