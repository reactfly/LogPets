import express, { type Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import session from "express-session";
import { insertTripSchema, insertFineSchema } from "@shared/schema";
import { z } from "zod";
import multer from "multer";
import path from "path";
import fs from "fs";

// Configure multer for file uploads
const uploadDir = path.join(process.cwd(), "uploads");
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const upload = multer({
  storage: multer.diskStorage({
    destination: uploadDir,
    filename: (req, file, cb) => {
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
      cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
    }
  }),
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB limit
  fileFilter: (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png|pdf/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);
    
    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb(new Error('Only images (jpeg, jpg, png) and PDF files are allowed'));
    }
  }
});

declare module "express-session" {
  interface SessionData {
    userId: number;
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Session configuration
  app.use(session({
    secret: process.env.SESSION_SECRET || 'logpet-secret-key',
    resave: false,
    saveUninitialized: false,
    cookie: { 
      secure: false, // Set to true in production with HTTPS
      httpOnly: true,
      maxAge: 24 * 60 * 60 * 1000 // 24 hours
    }
  }));

  // Authentication middleware
  const requireAuth = (req: any, res: any, next: any) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Authentication required" });
    }
    next();
  };

  // Login endpoint
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      if (username === "admin" && password === "102030ab") {
        // For demo, create or get admin user
        let user = await storage.getUserByUsername(username);
        if (!user) {
          user = await storage.createUser({ 
            username, 
            password, 
            email: "admin@logpet.com" 
          });
        }
        
        req.session.userId = user.id;
        res.json({ success: true, user: { id: user.id, username: user.username, email: user.email } });
      } else {
        res.status(401).json({ message: "Credenciais inválidas" });
      }
    } catch (error) {
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  // Logout endpoint
  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Erro ao fazer logout" });
      }
      res.json({ success: true });
    });
  });

  // Check authentication status
  app.get("/api/auth/me", requireAuth, async (req, res) => {
    try {
      const user = await storage.getUser(req.session.userId!);
      if (!user) {
        return res.status(404).json({ message: "Usuário não encontrado" });
      }
      res.json({ id: user.id, username: user.username, email: user.email });
    } catch (error) {
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  // Trip endpoints
  app.post("/api/trips", requireAuth, async (req, res) => {
    try {
      const tripData = insertTripSchema.parse(req.body);
      const trip = await storage.createTrip({ ...tripData, userId: req.session.userId! });
      res.json(trip);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Dados inválidos", errors: error.errors });
      }
      res.status(500).json({ message: "Erro ao criar viagem" });
    }
  });

  app.get("/api/trips", requireAuth, async (req, res) => {
    try {
      const { plate } = req.query;
      let trips;
      
      if (plate && typeof plate === "string") {
        trips = await storage.getTripsByPlate(req.session.userId!, plate);
      } else {
        trips = await storage.getTripsByUser(req.session.userId!);
      }
      
      res.json(trips);
    } catch (error) {
      res.status(500).json({ message: "Erro ao buscar viagens" });
    }
  });

  app.get("/api/trips/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const trip = await storage.getTrip(id, req.session.userId!);
      
      if (!trip) {
        return res.status(404).json({ message: "Viagem não encontrada" });
      }
      
      res.json(trip);
    } catch (error) {
      res.status(500).json({ message: "Erro ao buscar viagem" });
    }
  });

  app.put("/api/trips/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const tripData = insertTripSchema.partial().parse(req.body);
      
      const trip = await storage.updateTrip(id, req.session.userId!, tripData);
      
      if (!trip) {
        return res.status(404).json({ message: "Viagem não encontrada" });
      }
      
      res.json(trip);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Dados inválidos", errors: error.errors });
      }
      res.status(500).json({ message: "Erro ao atualizar viagem" });
    }
  });

  app.delete("/api/trips/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteTrip(id, req.session.userId!);
      
      if (!deleted) {
        return res.status(404).json({ message: "Viagem não encontrada" });
      }
      
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Erro ao deletar viagem" });
    }
  });

  // Fine endpoints
  app.post("/api/fines", requireAuth, upload.single('attachment'), async (req, res) => {
    try {
      const fineData = insertFineSchema.parse(req.body);
      
      if (req.file) {
        fineData.attachmentPath = req.file.filename;
      }
      
      const fine = await storage.createFine({ ...fineData, userId: req.session.userId! });
      res.json(fine);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Dados inválidos", errors: error.errors });
      }
      res.status(500).json({ message: "Erro ao criar multa" });
    }
  });

  app.get("/api/fines", requireAuth, async (req, res) => {
    try {
      const { plate } = req.query;
      let fines;
      
      if (plate && typeof plate === "string") {
        fines = await storage.getFinesByPlate(req.session.userId!, plate);
      } else {
        fines = await storage.getFinesByUser(req.session.userId!);
      }
      
      res.json(fines);
    } catch (error) {
      res.status(500).json({ message: "Erro ao buscar multas" });
    }
  });

  app.put("/api/fines/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const fineData = insertFineSchema.partial().parse(req.body);
      
      const fine = await storage.updateFine(id, req.session.userId!, fineData);
      
      if (!fine) {
        return res.status(404).json({ message: "Multa não encontrada" });
      }
      
      res.json(fine);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Dados inválidos", errors: error.errors });
      }
      res.status(500).json({ message: "Erro ao atualizar multa" });
    }
  });

  app.delete("/api/fines/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteFine(id, req.session.userId!);
      
      if (!deleted) {
        return res.status(404).json({ message: "Multa não encontrada" });
      }
      
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Erro ao deletar multa" });
    }
  });

  // Statistics endpoint
  app.get("/api/stats", requireAuth, async (req, res) => {
    try {
      const stats = await storage.getTripStats(req.session.userId!);
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Erro ao buscar estatísticas" });
    }
  });

  // Serve uploaded files
  app.use('/api/uploads', requireAuth, (req, res, next) => {
    // Additional security check - ensure file belongs to user
    next();
  }, express.static(uploadDir));

  const httpServer = createServer(app);
  return httpServer;
}
