# LogPet - Trip Management System

## Overview

LogPet is a full-stack web application for managing vehicle trips and fines. Built with React frontend and Express backend, it provides a mobile-first experience for tracking vehicle expenses, logging trips, and managing traffic fines with file attachments.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes (January 2025)

✓ **Logo Integration & Brand Update**: Integrated the official LogPet logo (teal background with animal silhouettes) throughout the application
✓ **Color Scheme Update**: Updated primary colors from green (#2E7D32) to teal (#18A192) to match the logo
✓ **Visual Branding**: Updated all pages to use the new teal color scheme and logo placement
✓ **Background Enhancement**: Updated app background to subtle teal gradient for brand consistency
✓ **Preloader Animation**: Added animated loading screen with LogPet logo, progress bar, and floating particles
✓ **Footer Addition**: Added copyright footer with LOGPETS and GROWMONEY DIGITAL branding in teal color scheme

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **UI Library**: Radix UI components with shadcn/ui styling
- **Styling**: Tailwind CSS with custom design tokens
- **State Management**: React Query (TanStack Query) for server state
- **Forms**: React Hook Form with Zod validation
- **Build Tool**: Vite with custom configuration

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon serverless PostgreSQL
- **Session Management**: Express sessions with PostgreSQL store
- **File Uploads**: Multer for handling attachments
- **API Design**: RESTful endpoints with JSON responses

### Mobile-First Design
- Responsive design optimized for mobile devices
- Bottom navigation with floating action button
- Touch-friendly interface elements
- PWA-ready architecture

## Key Components

### Database Schema
- **Users**: Authentication and user management
- **Trips**: Vehicle trip records with costs and details
- **Fines**: Traffic violation records with attachments

### Authentication System
- Session-based authentication
- Protected routes with automatic redirects
- User context management

### File Management
- Multer-based file upload system
- Support for images (JPEG, PNG) and PDFs
- 5MB file size limit
- Organized file storage in uploads directory

### UI Components
- Complete shadcn/ui component library
- Custom styled components with Tailwind
- Responsive design patterns
- Accessible form controls

## Data Flow

1. **Authentication Flow**:
   - Login → Session creation → Protected route access
   - Automatic session validation on protected routes
   - Logout clears session and redirects to login

2. **Trip Management Flow**:
   - Create trip → Form validation → Database storage
   - View trips → Query with optional filtering
   - Update/Delete → Authenticated operations

3. **Fine Management Flow**:
   - Create fine → Form validation → File upload → Database storage
   - View fines → Query with status filtering
   - Update fine status → Database update

4. **File Upload Flow**:
   - File selection → Validation → Multer processing → Storage → Database reference

## External Dependencies

### Frontend Dependencies
- React ecosystem (React, React DOM, React Hook Form)
- UI libraries (Radix UI, Lucide React icons)
- Utility libraries (clsx, tailwind-merge, date-fns)
- Development tools (Vite, TypeScript, Tailwind CSS)

### Backend Dependencies
- Express.js with TypeScript support
- Database tools (Drizzle ORM, Neon serverless client)
- File handling (Multer, file system operations)
- Session management (express-session, connect-pg-simple)
- Validation (Zod for schema validation)

### Database
- PostgreSQL via Neon serverless
- Connection pooling for performance
- Migration system with Drizzle Kit

## Deployment Strategy

### Development Environment
- Vite dev server for frontend hot reload
- tsx for TypeScript execution in development
- Integrated development with Replit tooling

### Production Build
- Vite build for optimized frontend bundle
- esbuild for backend compilation
- Static file serving from Express
- Environment-based configuration

### Database Management
- Drizzle migrations for schema changes
- Environment-based database URLs
- Automated schema synchronization

### Session Configuration
- Secure session management
- PostgreSQL session store for persistence
- Environment-based session secrets

The application follows a monorepo structure with shared TypeScript types and schemas, enabling type safety across the full stack while maintaining clear separation between frontend and backend concerns.