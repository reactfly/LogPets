import { useLocation } from "wouter";
import { Home, Plus, List, AlertTriangle, User } from "lucide-react";

interface BottomNavProps {
  onNewTrip: () => void;
}

export default function BottomNav({ onNewTrip }: BottomNavProps) {
  const [location, setLocation] = useLocation();

  const navItems = [
    { path: "/dashboard", icon: Home, label: "Início" },
    { path: "/new-trip", icon: Plus, label: "Nova", action: onNewTrip },
    { path: "/history", icon: List, label: "Histórico" },
    { path: "/fines", icon: AlertTriangle, label: "Multas" },
    { path: "/profile", icon: User, label: "Perfil" },
  ];

  return (
    <>
      <nav className="fixed bottom-12 left-0 right-0 bg-white border-t border-gray-200 px-4 py-2 z-50 mb-1">
        <div className="flex justify-around">
          {navItems.map((item) => {
            const isActive = location === item.path;
            const Icon = item.icon;
            
            return (
              <button
                key={item.path}
                onClick={() => item.action ? item.action() : setLocation(item.path)}
                className={`flex flex-col items-center py-2 px-3 ${
                  isActive ? "text-[#18A192]" : "text-gray-500"
                }`}
              >
                <Icon className="text-xl mb-1" size={24} />
                <span className="text-xs">{item.label}</span>
              </button>
            );
          })}
        </div>
      </nav>
      
      {/* Floating Action Button */}
      <button
        onClick={onNewTrip}
        className="fixed bottom-20 right-4 w-14 h-14 bg-[#18A192] text-white rounded-full shadow-lg flex items-center justify-center btn-elevation hover:bg-[#138A7E] transition-colors z-30"
      >
        <Plus size={24} />
      </button>
    </>
  );
}
